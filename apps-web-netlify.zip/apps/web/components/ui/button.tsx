import type { ButtonHTMLAttributes } from "react";
import { cn } from "@/components/ui/cn";

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "secondary" | "ghost" | "danger";
};

export function Button({ className, variant = "primary", ...props }: ButtonProps) {
  const variants: Record<NonNullable<ButtonProps["variant"]>, string> = {
    primary:
      "bg-cyan-400 text-slate-950 shadow-[0_0_0_1px_rgba(255,255,255,0.08)] hover:bg-cyan-300",
    secondary:
      "bg-white/6 text-slate-100 ring-1 ring-white/10 hover:bg-white/10",
    ghost: "bg-transparent text-slate-200 hover:bg-white/5",
    danger: "bg-rose-500 text-white hover:bg-rose-400"
  };

  return (
    <button
      className={cn(
        "inline-flex items-center justify-center gap-2 rounded-xl px-4 py-2 text-sm font-medium transition-all duration-200 disabled:cursor-not-allowed disabled:opacity-50",
        variants[variant],
        className
      )}
      {...props}
    />
  );
}
