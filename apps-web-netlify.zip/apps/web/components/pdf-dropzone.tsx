"use client";

import { useRef, useState } from "react";
import { FileUp, FileText, Sparkles, X } from "lucide-react";
import { cn } from "@/components/ui/cn";
import { Button } from "@/components/ui/button";

type PdfDropzoneProps = {
  file: File | null;
  onFileSelected: (file: File) => void;
  onInvalid?: (message: string) => void;
  onClear: () => void;
  disabled?: boolean;
  maxSizeMb?: number;
};

export function PdfDropzone({
  file,
  onFileSelected,
  onInvalid,
  onClear,
  disabled = false,
  maxSizeMb = 10
}: PdfDropzoneProps) {
  const inputRef = useRef<HTMLInputElement | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  const handleFile = (selectedFile: File | null | undefined) => {
    if (!selectedFile) {
      onInvalid?.("No se pudo leer el archivo seleccionado.");
      return;
    }

    const isPdf = selectedFile.type === "application/pdf" || selectedFile.name.toLowerCase().endsWith(".pdf");
    if (!isPdf) {
      onInvalid?.("Solo se admiten archivos PDF.");
      return;
    }

    if (selectedFile.size > maxSizeMb * 1024 * 1024) {
      onInvalid?.(`El archivo supera el límite de ${maxSizeMb} MB.`);
      return;
    }

    onFileSelected(selectedFile);
  };

  return (
    <div className="space-y-4">
      <div
        role="button"
        tabIndex={0}
        aria-label="Zona para subir PDF"
        onClick={() => inputRef.current?.click()}
        onKeyDown={(event) => {
          if (event.key === "Enter" || event.key === " ") {
            event.preventDefault();
            inputRef.current?.click();
          }
        }}
        onDragEnter={(event) => {
          event.preventDefault();
          event.stopPropagation();
          if (!disabled) setIsDragging(true);
        }}
        onDragOver={(event) => {
          event.preventDefault();
          event.stopPropagation();
          if (!disabled) setIsDragging(true);
        }}
        onDragLeave={(event) => {
          event.preventDefault();
          event.stopPropagation();
          setIsDragging(false);
        }}
        onDrop={(event) => {
          event.preventDefault();
          event.stopPropagation();
          setIsDragging(false);
          handleFile(event.dataTransfer.files?.[0]);
        }}
        className={cn(
          "group relative overflow-hidden rounded-3xl border border-white/10 bg-white/5 p-8 shadow-glow backdrop-blur-xl transition-all duration-300",
          "focus:outline-none focus:ring-2 focus:ring-cyan-400/60 focus:ring-offset-0",
          isDragging && "border-cyan-300/70 bg-cyan-400/10 shadow-[0_0_0_1px_rgba(34,211,238,0.2),0_30px_90px_rgba(2,132,199,0.18)]",
          disabled && "cursor-not-allowed opacity-70"
        )}
      >
        <div className="pointer-events-none absolute inset-0 grid-noise opacity-40" />
        <div className="pointer-events-none absolute -left-20 top-0 h-40 w-40 rounded-full bg-cyan-400/20 blur-3xl transition-all duration-300 group-hover:bg-cyan-400/25" />
        <div className="pointer-events-none absolute -right-20 bottom-0 h-40 w-40 rounded-full bg-emerald-400/20 blur-3xl transition-all duration-300 group-hover:bg-emerald-400/25" />

        <input
          ref={inputRef}
          type="file"
          accept="application/pdf,.pdf"
          className="hidden"
          onChange={(event) => handleFile(event.target.files?.[0])}
          disabled={disabled}
        />

        <div className="relative flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
          <div className="space-y-4">
            <div className="inline-flex items-center gap-2 rounded-full border border-cyan-400/20 bg-cyan-400/10 px-3 py-1 text-xs font-medium text-cyan-200">
              <Sparkles className="h-3.5 w-3.5" />
              Carga un PDF para resumirlo
            </div>
            <div className="space-y-2">
              <h2 className="text-2xl font-semibold tracking-tight text-white md:text-3xl">
                Arrastra tu PDF aquí o haz clic para buscarlo
              </h2>
              <p className="max-w-2xl text-sm leading-6 text-slate-300">
                Se admiten archivos PDF de hasta {maxSizeMb} MB. El documento se procesa de forma segura y el archivo no se conserva.
              </p>
            </div>

            {file ? (
              <div className="flex flex-wrap items-center gap-3 rounded-2xl border border-white/10 bg-black/20 px-4 py-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-cyan-400/15 text-cyan-200">
                  <FileText className="h-5 w-5" />
                </div>
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium text-white">{file.name}</p>
                  <p className="text-xs text-slate-400">{(file.size / (1024 * 1024)).toFixed(2)} MB</p>
                </div>
                <Button variant="ghost" type="button" className="ml-auto" onClick={onClear} disabled={disabled}>
                  <X className="h-4 w-4" />
                  Quitar
                </Button>
              </div>
            ) : null}
          </div>

          <div className="flex flex-col items-start gap-3 rounded-2xl border border-white/10 bg-black/20 p-4 text-sm text-slate-300 md:min-w-72">
            <div className="flex items-center gap-2 text-white">
              <FileUp className="h-4 w-4 text-cyan-300" />
              Flujo de trabajo
            </div>
            <ul className="space-y-2">
              <li>1. El archivo se sube con límite seguro.</li>
              <li>2. Se extrae el texto por páginas.</li>
              <li>3. La IA genera el resumen estructurado.</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
