"use client";

import { cn } from "@/components/ui/cn";
import type { UploadPhase } from "@/lib/types";
import { Loader2, ScanText, Sparkles, UploadCloud, CircleCheckBig } from "lucide-react";
import type { ComponentType } from "react";

type StatusStepsProps = {
  phase: UploadPhase;
};

const steps: Array<{
  key: UploadPhase;
  label: string;
  icon: ComponentType<{ className?: string }>;
}> = [
  { key: "uploading", label: "Cargando archivo...", icon: UploadCloud },
  { key: "extracting", label: "Procesando texto...", icon: ScanText },
  { key: "summarizing", label: "Generando resumen local...", icon: Sparkles },
  { key: "success", label: "Resumen listo", icon: CircleCheckBig }
];

export function StatusSteps({ phase }: StatusStepsProps) {
  const activeIndex = steps.findIndex((step) => step.key === phase);
  const progress = phase === "success" ? 100 : phase === "error" || phase === "idle" ? 0 : activeIndex >= 0 ? Math.min(95, 30 + activeIndex * 30) : 0;

  return (
    <div className="rounded-3xl border border-white/10 bg-white/5 p-5 shadow-glow backdrop-blur-xl">
      <div className="mb-4 flex items-center justify-between gap-3">
        <div>
          <p className="text-sm font-medium text-white">Estado del proceso</p>
          <p className="text-xs text-slate-400">Indicadores animados en tiempo real</p>
        </div>
        {phase === "idle" ? (
          <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-black/20 px-3 py-1 text-xs text-slate-300">
            <Loader2 className="h-3.5 w-3.5 animate-spin" />
            Listo para empezar
          </span>
        ) : null}
      </div>

      <div className="mb-4 h-2 overflow-hidden rounded-full bg-black/30">
        <div
          className="h-full rounded-full bg-gradient-to-r from-cyan-300 via-emerald-300 to-cyan-200 transition-all duration-500"
          style={{ width: `${progress}%` }}
        />
      </div>

      <div className="grid gap-3 md:grid-cols-4">
        {steps.map((step, index) => {
          const isComplete = phase === "success" || (activeIndex >= 0 && index < activeIndex);
          const isActive = step.key === phase;
          const Icon = step.icon;

          return (
            <div
              key={step.key}
              className={cn(
                "flex items-center gap-3 rounded-2xl border px-4 py-3 transition-all duration-300",
                isActive
                  ? "border-cyan-300/40 bg-cyan-400/10 text-white"
                  : isComplete
                    ? "border-emerald-400/20 bg-emerald-400/10 text-white"
                    : "border-white/10 bg-black/10 text-slate-400"
              )}
            >
              <div
                className={cn(
                  "flex h-9 w-9 items-center justify-center rounded-xl",
                  isActive
                    ? "bg-cyan-400/20 text-cyan-200"
                    : isComplete
                      ? "bg-emerald-400/15 text-emerald-200"
                      : "bg-white/5 text-slate-400"
                )}
              >
                <Icon className={cn("h-4 w-4", isActive && "animate-pulseSoft")} />
              </div>
              <div className="min-w-0">
                <p className="truncate text-sm font-medium">{step.label}</p>
                <p className="text-xs text-slate-500">{isActive ? "En curso" : isComplete ? "Completado" : "Pendiente"}</p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
