"use client";

import { AlertTriangle, ShieldAlert } from "lucide-react";

type ErrorAlertProps = {
  message: string | null;
};

export function ErrorAlert({ message }: ErrorAlertProps) {
  if (!message) return null;

  return (
    <div className="rounded-3xl border border-rose-500/30 bg-rose-500/10 p-5 text-rose-50 shadow-glow backdrop-blur-xl">
      <div className="flex gap-3">
        <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-rose-500/15 text-rose-200">
          <ShieldAlert className="h-5 w-5" />
        </div>
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 text-rose-200" />
            <p className="font-semibold">No se pudo procesar el archivo</p>
          </div>
          <p className="text-sm leading-6 text-rose-100/90">{message}</p>
        </div>
      </div>
    </div>
  );
}
