"use client";

import { useMemo } from "react";
import { Clipboard, Check, BookOpenText, FileText, ListChecks, BadgeCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/components/ui/cn";
import type { SummaryResult } from "@/lib/types";
import { formatSummaryForClipboard } from "@/lib/format";

type SummaryViewerProps = {
  summary: SummaryResult | null;
  copied: boolean;
  onCopy: () => void;
};

export function SummaryViewer({ summary, copied, onCopy }: SummaryViewerProps) {
  const clipboardText = useMemo(() => (summary ? formatSummaryForClipboard(summary) : ""), [summary]);

  if (!summary) {
    return (
      <div className="rounded-3xl border border-dashed border-white/10 bg-white/5 p-8 text-slate-300 shadow-glow backdrop-blur-xl">
        <div className="flex items-center gap-3 text-white">
          <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-white/5">
            <BookOpenText className="h-5 w-5 text-cyan-300" />
          </div>
          <div>
            <p className="font-medium">Tu resumen aparecerá aquí</p>
            <p className="text-sm text-slate-400">Sube un PDF para ver el resultado estructurado.</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <section className="rounded-3xl border border-white/10 bg-white/5 p-6 shadow-glow backdrop-blur-xl">
      <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-2 rounded-full border border-emerald-400/20 bg-emerald-400/10 px-3 py-1 text-xs text-emerald-200">
            <BadgeCheck className="h-3.5 w-3.5" />
            Resumen estructurado
          </div>
          <h2 className="text-2xl font-semibold tracking-tight text-white">Resultado del análisis</h2>
        </div>

        <Button
          variant="secondary"
          type="button"
          onClick={async () => {
            try {
              await navigator.clipboard.writeText(clipboardText);
              onCopy();
            } catch {
              // Si el navegador bloquea Clipboard API, no rompemos la UI.
            }
          }}
        >
          {copied ? <Check className="h-4 w-4" /> : <Clipboard className="h-4 w-4" />}
          {copied ? "¡Copiado!" : "Copiar al portapapeles"}
        </Button>
      </div>

      <div className="grid gap-5">
        <article className="rounded-2xl border border-white/10 bg-black/20 p-5">
          <div className="mb-3 flex items-center gap-2 text-cyan-200">
            <FileText className="h-4 w-4" />
            <h3 className="text-sm font-semibold uppercase tracking-[0.18em]">Título</h3>
          </div>
          <p className="text-xl font-semibold text-white">{summary.title}</p>
        </article>

        <article className="rounded-2xl border border-white/10 bg-black/20 p-5">
          <div className="mb-3 flex items-center gap-2 text-cyan-200">
            <BookOpenText className="h-4 w-4" />
            <h3 className="text-sm font-semibold uppercase tracking-[0.18em]">Resumen Ejecutivo</h3>
          </div>
          <p className="leading-7 text-slate-200">{summary.executiveSummary}</p>
        </article>

        <article className="rounded-2xl border border-white/10 bg-black/20 p-5">
          <div className="mb-4 flex items-center gap-2 text-cyan-200">
            <ListChecks className="h-4 w-4" />
            <h3 className="text-sm font-semibold uppercase tracking-[0.18em]">Puntos Clave</h3>
          </div>
          <ul className="space-y-3">
            {summary.keyPoints.map((point, index) => (
              <li key={`${point}-${index}`} className="flex gap-3 rounded-2xl border border-white/10 bg-white/5 p-4 text-slate-200">
                <span className="mt-1 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-cyan-400/15 text-xs font-semibold text-cyan-200">
                  {index + 1}
                </span>
                <span className="leading-7">{point}</span>
              </li>
            ))}
          </ul>
        </article>

        <article className="rounded-2xl border border-white/10 bg-black/20 p-5">
          <div className="mb-3 flex items-center gap-2 text-cyan-200">
            <BadgeCheck className="h-4 w-4" />
            <h3 className="text-sm font-semibold uppercase tracking-[0.18em]">Conclusión</h3>
          </div>
          <p className="leading-7 text-slate-200">{summary.conclusion}</p>
        </article>
      </div>

      <div className={cn("mt-4 text-xs text-slate-500", copied && "text-emerald-300")}>
        El texto copiado incluye todas las secciones del resumen.
      </div>
    </section>
  );
}
