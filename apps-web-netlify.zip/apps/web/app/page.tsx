"use client";

import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { PdfDropzone } from "@/components/pdf-dropzone";
import { StatusSteps } from "@/components/status-steps";
import { SummaryViewer } from "@/components/summary-viewer";
import { ErrorAlert } from "@/components/error-alert";
import { summarizePdf } from "@/lib/api";
import type { SummaryResult, UploadPhase } from "@/lib/types";
import { Loader2 } from "lucide-react";

const MAX_SIZE_MB = 10;

export default function HomePage() {
  const [file, setFile] = useState<File | null>(null);
  const [summary, setSummary] = useState<SummaryResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [phase, setPhase] = useState<UploadPhase>("idle");
  const [copying, setCopying] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const timerRef = useRef<number | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  useEffect(() => {
    if (phase === "idle" || phase === "success" || phase === "error") return;

    const sequence: UploadPhase[] = ["uploading", "extracting", "summarizing"];
    let index = sequence.indexOf(phase);

    timerRef.current = window.setInterval(() => {
      index = Math.min(index + 1, sequence.length - 1);
      setPhase(sequence[index]);
    }, 1800);

    return () => {
      if (timerRef.current) {
        window.clearInterval(timerRef.current);
        timerRef.current = null;
      }
    };
  }, [phase]);

  useEffect(() => {
    return () => {
      abortRef.current?.abort();
    };
  }, []);

  const validateFile = (selectedFile: File) => {
    const isPdf = selectedFile.type === "application/pdf" || selectedFile.name.toLowerCase().endsWith(".pdf");
    if (!isPdf) {
      setError("Solo se admiten archivos PDF.");
      return false;
    }

    if (selectedFile.size > MAX_SIZE_MB * 1024 * 1024) {
      setError(`El archivo supera el límite de ${MAX_SIZE_MB} MB.`);
      return false;
    }

    return true;
  };

  const handleFileSelected = (selectedFile: File) => {
    setError(null);
    setSummary(null);
    setFile(selectedFile);
  };

  const handleClear = () => {
    setFile(null);
    setSummary(null);
    setError(null);
    setPhase("idle");
  };

  const handleSummarize = async () => {
    if (!file || !validateFile(file) || isSubmitting) return;

    setIsSubmitting(true);
    setError(null);
    setSummary(null);
    setPhase("uploading");

    abortRef.current?.abort();
    abortRef.current = new AbortController();

    try {
      const response = await summarizePdf(file, abortRef.current.signal);

      if (response.success) {
        setPhase("success");
        setSummary(response.data);
        return;
      }

      setPhase("error");
      setError(response.error.message);
    } catch {
      setPhase("error");
      setError("No fue posible conectar con el backend.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCopyDone = async () => {
    setCopying(true);
    window.setTimeout(() => setCopying(false), 1500);
  };

  return (
    <main className="relative min-h-screen overflow-hidden">
      <div className="absolute inset-0 grid-noise opacity-30" />
      <div className="absolute left-1/2 top-0 h-72 w-[44rem] -translate-x-1/2 rounded-full bg-cyan-500/15 blur-3xl" />
      <div className="absolute right-0 top-40 h-80 w-80 rounded-full bg-emerald-500/10 blur-3xl" />

      <div className="relative mx-auto flex min-h-screen w-full max-w-7xl flex-col px-4 py-8 sm:px-6 lg:px-8">
        <header className="mb-10 flex flex-col gap-4 rounded-3xl border border-white/10 bg-white/5 px-6 py-5 shadow-glow backdrop-blur-xl md:flex-row md:items-center md:justify-between">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.3em] text-cyan-200">PDF Summarizer</p>
            <h1 className="mt-2 text-3xl font-semibold tracking-tight text-white md:text-5xl">
              Resumidor de archivos PDF
            </h1>
            <p className="mt-3 max-w-2xl text-sm leading-6 text-slate-300 md:text-base">
              Sube un documento y obtén un resumen estructurado con título, resumen ejecutivo, puntos clave y conclusión.
            </p>
          </div>

          <div className="flex items-center gap-3 rounded-2xl border border-white/10 bg-black/20 px-4 py-3 text-sm text-slate-300">
            <Loader2 className="h-4 w-4 animate-spin text-cyan-300" />
            Procesamiento local listo en el navegador
          </div>
        </header>

        <div className="grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
          <section className="space-y-6">
            <PdfDropzone
              file={file}
              onFileSelected={handleFileSelected}
              onInvalid={(message) => setError(message)}
              onClear={handleClear}
              disabled={isSubmitting}
              maxSizeMb={MAX_SIZE_MB}
            />

            <div className="flex flex-wrap gap-3">
              <Button type="button" onClick={handleSummarize} disabled={!file || isSubmitting} className="min-w-44">
                {isSubmitting ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
                {isSubmitting ? "Procesando..." : "Generar resumen"}
              </Button>
              <Button variant="secondary" type="button" onClick={handleClear} disabled={isSubmitting || (!file && !summary && !error)}>
                Limpiar
              </Button>
            </div>

            <ErrorAlert message={error} />

            <StatusSteps phase={phase} />
          </section>

          <section className="space-y-6">
            <SummaryViewer summary={summary} copied={copying} onCopy={handleCopyDone} />
          </section>
        </div>
      </div>
    </main>
  );
}
