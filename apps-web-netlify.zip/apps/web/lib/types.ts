export type SummaryResult = {
  title: string;
  executiveSummary: string;
  keyPoints: string[];
  conclusion: string;
};

export type SummarizeApiResponse =
  | {
      success: true;
      data: SummaryResult;
      meta?: {
        fileName: string;
        mimeType: string;
        size: number;
        pageCount: number;
        extractedCharacters: number;
      };
    }
  | {
      success: false;
      error: {
        code: string;
        message: string;
        details?: unknown;
      };
    };

export type UploadPhase = "idle" | "uploading" | "extracting" | "summarizing" | "success" | "error";
