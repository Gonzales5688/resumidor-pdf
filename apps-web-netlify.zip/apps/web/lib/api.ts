import type { SummarizeApiResponse, SummaryResult } from "./types";

const MAX_SIZE_BYTES = 10 * 1024 * 1024;

const STOP_WORDS = new Set([
  "a",
  "acá",
  "ahora",
  "al",
  "algo",
  "algunas",
  "algunos",
  "ante",
  "antes",
  "como",
  "con",
  "contra",
  "cual",
  "cuando",
  "de",
  "del",
  "desde",
  "donde",
  "dos",
  "el",
  "ella",
  "ellas",
  "ellos",
  "en",
  "entre",
  "era",
  "eramos",
  "es",
  "esa",
  "esas",
  "ese",
  "eso",
  "esta",
  "estaba",
  "estaban",
  "estamos",
  "está",
  "están",
  "este",
  "esto",
  "estos",
  "fue",
  "fueron",
  "ha",
  "han",
  "hasta",
  "hay",
  "la",
  "las",
  "le",
  "les",
  "lo",
  "los",
  "me",
  "mi",
  "mis",
  "mucho",
  "muy",
  "no",
  "nos",
  "o",
  "para",
  "pero",
  "por",
  "que",
  "qué",
  "se",
  "sin",
  "sobre",
  "su",
  "sus",
  "te",
  "tiene",
  "tienen",
  "todo",
  "todos",
  "tu",
  "un",
  "una",
  "uno",
  "unos",
  "y",
  "ya"
]);

type ExtractedPdf = {
  text: string;
  pageCount: number;
};

function normalizeText(text: string): string {
  return text.replace(/\s+/g, " ").replace(/\u0000/g, " ").trim();
}

function capitalizeWords(text: string): string {
  return text
    .split(/\s+/)
    .filter(Boolean)
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
    .join(" ");
}

function deriveTitle(fileName: string, text: string): string {
  const baseName = fileName.replace(/\.pdf$/i, "").replace(/[_-]+/g, " ").trim();
  const textCandidate = text.split(/\n+/).find((line) => line.trim().length >= 10);
  const source = textCandidate ?? baseName ?? "Documento PDF";
  return capitalizeWords(source.replace(/[^\p{L}\p{N}\s]/gu, " ").slice(0, 80).trim()) || "Documento PDF";
}

function extractKeywords(text: string, limit = 6): string[] {
  const frequencies = new Map<string, number>();
  const words = text.toLowerCase().match(/\p{L}{4,}/gu) ?? [];

  for (const word of words) {
    if (STOP_WORDS.has(word)) continue;
    frequencies.set(word, (frequencies.get(word) ?? 0) + 1);
  }

  return [...frequencies.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit)
    .map(([word]) => capitalizeWords(word));
}

function splitSentences(text: string): string[] {
  return text
    .replace(/\s+/g, " ")
    .split(/(?<=[.!?])\s+/)
    .map((sentence) => sentence.trim())
    .filter((sentence) => sentence.length >= 40);
}

function scoreSentence(sentence: string, keywordSet: Set<string>): number {
  const words = sentence.toLowerCase().match(/\p{L}{4,}/gu) ?? [];
  let score = 0;

  for (const word of words) {
    if (STOP_WORDS.has(word)) continue;
    if (keywordSet.has(capitalizeWords(word))) {
      score += 2;
    } else {
      score += 1;
    }
  }

  return score;
}

function buildSummary(text: string, fileName: string, pageCount: number): SummaryResult {
  const normalized = normalizeText(text);
  const sentences = splitSentences(normalized);
  const keywords = extractKeywords(normalized);
  const keywordSet = new Set(keywords);
  const ranked = sentences
    .map((sentence, index) => ({
      sentence,
      score: scoreSentence(sentence, keywordSet),
      index
    }))
    .sort((left, right) => right.score - left.score || left.index - right.index);

  const keyPoints = ranked
    .slice(0, Math.min(4, ranked.length))
    .map((item) => item.sentence.replace(/\s+/g, " ").trim())
    .filter(Boolean);

  const lead = sentences.slice(0, 2).join(" ");
  const tail = sentences.slice(-1)[0] ?? "";
  const title = deriveTitle(fileName, normalized);

  return {
    title,
    executiveSummary:
      lead ||
      `El documento contiene aproximadamente ${pageCount} página(s) y fue procesado localmente en el navegador para generar una síntesis preliminar.`,
    keyPoints:
      keyPoints.length > 0
        ? keyPoints
        : [
            "El archivo fue analizado de forma local, sin subir su contenido a un servidor.",
            `Se identificaron como temas dominantes: ${keywords.length > 0 ? keywords.join(", ") : "no se detectaron términos dominantes claros"}.`,
            "La vista está optimizada para funcionar como sitio estático en Netlify Drop.",
            "Si más adelante necesitas IA real, podrás conectar una función serverless."
          ],
    conclusion:
      tail ||
      "En conjunto, el documento puede consultarse desde una experiencia completamente estática y segura en el navegador."
  };
}

async function extractPdfText(file: File, signal?: AbortSignal): Promise<ExtractedPdf> {
  if (signal?.aborted) {
    throw new DOMException("La operación fue cancelada.", "AbortError");
  }

  const buffer = await file.arrayBuffer();
  const bytes = new Uint8Array(buffer);
  const header = String.fromCharCode(...bytes.slice(0, 5));
  if (header !== "%PDF-") {
    throw new Error("Solo se admiten archivos PDF.");
  }

  const pdfjs = await import("pdfjs-dist/legacy/build/pdf.mjs");
  pdfjs.GlobalWorkerOptions.workerSrc = "/pdf.worker.mjs";

  const loadingTask = pdfjs.getDocument({
    data: buffer,
    useSystemFonts: true
  });

  const pdf = await loadingTask.promise;
  const pageCount = pdf.numPages;
  const pageTexts: string[] = [];

  try {
    for (let pageNumber = 1; pageNumber <= pageCount; pageNumber += 1) {
      if (signal?.aborted) {
        throw new DOMException("La operación fue cancelada.", "AbortError");
      }

      const page = await pdf.getPage(pageNumber);
      const content = await page.getTextContent();
      const lines = content.items
        .map((item) => (typeof item === "object" && item !== null && "str" in item ? String((item as { str?: string }).str ?? "") : ""))
        .filter(Boolean);

      pageTexts.push(normalizeText(lines.join(" ")));
    }
  } finally {
    await pdf.destroy();
    await loadingTask.destroy();
  }

  const text = normalizeText(pageTexts.join("\n\n"));

  if (!text) {
    throw new Error("El PDF no contiene texto almacenado; probablemente es un documento escaneado.");
  }

  return {
    text,
    pageCount
  };
}

export async function summarizePdf(file: File, signal?: AbortSignal): Promise<SummarizeApiResponse> {
  try {
    if (file.size > MAX_SIZE_BYTES) {
      return {
        success: false,
        error: {
          code: "FILE_TOO_LARGE",
          message: "El archivo supera el límite seguro de 10 MB."
        }
      };
    }

    const extracted = await extractPdfText(file, signal);
    const summary = buildSummary(extracted.text, file.name, extracted.pageCount);

    return {
      success: true,
      data: summary,
      meta: {
        fileName: file.name,
        mimeType: file.type || "application/pdf",
        size: file.size,
        pageCount: extracted.pageCount,
        extractedCharacters: extracted.text.length
      }
    };
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);

    if (error instanceof DOMException && error.name === "AbortError") {
      return {
        success: false,
        error: {
          code: "ABORTED",
          message: "La operación fue cancelada."
        }
      };
    }

    if (/password|encrypted/i.test(message)) {
      return {
        success: false,
        error: {
          code: "PDF_PASSWORD_PROTECTED",
          message: "El PDF está protegido con contraseña y no puede procesarse."
        }
      };
    }

    if (/invalidpdf|corrupt|damaged|syntax|no contiene texto/i.test(message)) {
      return {
        success: false,
        error: {
          code: /no contiene texto/i.test(message) ? "PDF_SCANNED_NO_TEXT" : "PDF_CORRUPT",
          message
        }
      };
    }

    return {
      success: false,
      error: {
        code: "LOCAL_PROCESSING_ERROR",
        message: "No fue posible procesar el PDF localmente."
      }
    };
  }
}
