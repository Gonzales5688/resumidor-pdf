import type { SummaryResult } from "./types";

export function formatSummaryForClipboard(summary: SummaryResult): string {
  return [
    `Título: ${summary.title}`,
    "",
    `Resumen ejecutivo:`,
    summary.executiveSummary,
    "",
    `Puntos clave:`,
    ...summary.keyPoints.map((point) => `- ${point}`),
    "",
    `Conclusión:`,
    summary.conclusion
  ].join("\n");
}
